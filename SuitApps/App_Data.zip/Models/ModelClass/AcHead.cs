﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class AcHead
    {
        public string AccountCode { get; set; }
        public string HName { get; set; }
        public string GUnder { get; set; }
        public string UserId { get; set; }
        public string UDate { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
    }
}