﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class DBconnect
    { 
        public static SqlConnection getDataBaseConnection()
        {
            //string connectionString = " Data Source=43.255.152.26;Initial Catalog=SuitApps_Offline_TierraFoods;User Id=SuitApps_Offline_TierraFoods;Password=SuitApps_Offline_TierraFoods";
            //string connectionString = " Data Source=43.255.152.26;Initial Catalog=SuitApps_OfflineMV;User Id=SuitApps_OfflineMV;Password=SuitApps_OfflineMV";
          //  string connectionString = " Data Source=43.255.152.25;Initial Catalog=SuitApps_BestIndia3;User Id=SuitApps_BestIndia3;Password=SuitApps_BestIndia3@123";
           // string connectionString = " Data Source=MICROTECH-JYOTH;Initial Catalog=bestindia3;Integrated Security=SSPI;";
            string connectionString = " Data Source=43.255.152.25;Initial Catalog=SuitApps_OfficeTestMob2;User Id=SuitApps_OfficeTestMob2;Password=SuitApps_OfficeTestMob2@123";
            //string connectionString = " Data Source=43.255.152.26;Initial Catalog=SuitApps_thomasnewtest;User Id=SuitApps_thomasnewtestSuitApps_thomasnewtest;Password=SuitApps_thomasnewtest";
            SqlConnection con = new SqlConnection(connectionString);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
    }
}