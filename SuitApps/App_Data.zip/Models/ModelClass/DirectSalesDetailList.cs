﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class DirectSalesDetailList
    {
        public List<DirectSalesDetail> directSalesDetailList{ get; set; }
    }
}