﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class DirectSalesList
    {
        public List<DirectSales> directSalesList { get; set; }
        public string Message { get; set; }
    }
}