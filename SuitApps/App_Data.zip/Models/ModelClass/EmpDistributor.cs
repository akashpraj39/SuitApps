﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class EmpDistributor
    {
        public string DistID { get; set; }
        public string EmpID { get; set; }
        public string Distributor { get; set; }
        public string DistributorID { get; set; }
        public string CompanyID { get; set; }
        public string Status { get; set; }
    }
}