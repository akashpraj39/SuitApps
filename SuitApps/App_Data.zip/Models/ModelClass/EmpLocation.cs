﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class EmpLocation
    {
        public string EmpLocID { get; set; }
        public string EmpID { get; set; }
        public string Date { get; set; }
        public string Place { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string Message { get; set; }


    }
}