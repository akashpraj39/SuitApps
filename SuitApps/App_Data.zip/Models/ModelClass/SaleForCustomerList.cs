﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SuitApps.Models.ModelClass
{
    public class SaleForCustomerList
    {
       public List<SaleForCustomer> saleForCustomerList { get; set; }
       public string message { get; set; }
    }
}